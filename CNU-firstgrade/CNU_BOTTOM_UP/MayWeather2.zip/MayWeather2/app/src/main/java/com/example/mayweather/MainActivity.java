package com.example.mayweather;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.icu.util.RangeValueIterator;
import android.location.Location;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnSuccessListener;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLEncoder;

public class MainActivity extends Activity {
    private static final int REQUEST_CODE_PERMISSIONS = 1000;
    private FusedLocationProviderClient mFusedLocationClient;
    public static double lat;
    public static double lon;

    EditText edit;
    TextView text;

    XmlPullParser xpp;
    String key = "zTfsQLWs8T%2BxfCEzdpLNFa9kTbYTB1YizofKVg%2F1z3A7kbs4hQJPy%2FflhVirOgWiws1yuWsCs6eU9eSvQSSAew%3D%3D";

    String data;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        text = (TextView) findViewById(R.id.result);
    }

    //Button을 클릭했을 때 자동으로 호출되는 callback method....
    public void mOnClick(View v) {
        switch (v.getId()) {
            case R.id.button:

                //Android 4.0 이상 부터는 네트워크를 이용할 때 반드시 Thread 사용해야 함
                new Thread(new Runnable() {

                    @Override
                    public void run() {
                        // TODO Auto-generated method stub
                        setlocation();
                        data = getXmlData();//아래 메소드를 호출하여 XML data를 파싱해서 String 객체로 얻어오기

                        //UI Thread(Main Thread)를 제외한 어떤 Thread도 화면을 변경할 수 없기때문에
                        //runOnUiThread()를 이용하여 UI Thread가 TextView 글씨 변경하도록 함
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                // TODO Auto-generated method stub
                                text.setText(data); //TextView에 문자열  data 출력
                            }
                        });
                    }
                }).start();
                break;
        }
    }//mOnClick method..

    String getXmlData() {

        StringBuffer buffer = new StringBuffer();

        String queryUrl = "http://api.openweathermap.org/data/2.5/weather?lat="
                +lat
                + "&lon="
                +lon
                + "&APPID=59286b1f1fa10ded6b089e7892a4f0bf&mode=xml&units=metric";

        try {
            URL url = new URL(queryUrl);//문자열로 된 요청 url을 URL 객체로 생성.

            InputStream is = url.openStream(); //url위치로 입력스트림 연결

            XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
            XmlPullParser xpp = factory.newPullParser();
            xpp.setInput(new InputStreamReader(is, "UTF-8")); //inputstream 으로부터 xml 입력받기

            String tag;
            String recentTem;
            String recentHum;
            String windSpe;
            String windDir;
            String weather;

            xpp.next();
            int eventType = xpp.getEventType();


            while (eventType != XmlPullParser.END_DOCUMENT) {
                switch (eventType) {
                    case XmlPullParser.START_DOCUMENT:
                        break;

                    case XmlPullParser.START_TAG:
                        tag = xpp.getName();//테그 이름 얻어오기

                        if (tag.equals("temperature")) {//temperature 태그
                            recentTem = xpp.getAttributeValue(null, "value");
                            buffer.append("현재 온도 : "+ recentTem+ "\n");
                        }

                        else if (tag.equals("humidity")) {
                            recentHum = xpp.getAttributeValue(null, "value");
                            buffer.append("현재 습도 : "+ recentHum+ "\n");
                        }

                        else if(tag.equals("speed")){
                            windSpe = xpp.getAttributeValue(null,"name");
                            buffer.append("풍속 : "+ windSpe + "\n");
                        }
                        else if(tag.equals("direction")){
                            windDir = xpp.getAttributeValue(null,"name");
                            buffer.append("풍향 : "+ windDir + "\n");
                        }
                        else if (tag.equals("weather")){
                            weather = xpp.getAttributeValue(null,"value");
                            buffer.append("날씨 : "+ weather + "\n");

                        }
                        break;

                    case XmlPullParser.TEXT:
                        break;

                    case XmlPullParser.END_TAG:
                       break;
                }

                eventType = xpp.next();
            }

        } catch (Exception e) {
            buffer.append("catch!!");
            // TODO Auto-generated catch blocke.printStackTrace();
        }
        return buffer.toString();//StringBuffer 문자열 객체 반환

    }
    public void setlocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {  // 위치접근 권한 유무 확인

            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION},
                    REQUEST_CODE_PERMISSIONS); // 사용자에게 위치접근 요청
            return;
        }
        mFusedLocationClient.getLastLocation().addOnSuccessListener(this, new OnSuccessListener<Location>() {
            @Override
            public void onSuccess(Location location) {
                if (location != null) {
//                    LatLng myLocation = new LatLng(location.getLatitude(), location.getLongitude());  //위도, 경도 잡음
                    lat = location.getLatitude();
                    lon = location.getLongitude();  // 위도, 경도를 변수에 저장
                }
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) { // 요청을 처리함
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {  // 권한 수락시 다시 체크
            case REQUEST_CODE_PERMISSIONS:
                if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(this, "권한 체크 거부 됨", Toast.LENGTH_SHORT).show();
                }
        }
    }
}


